export class customerlogindetail
{
    phoneNo:number;
    passWord:String;
    public constructor(phoneNo:number, password:String)
    {
        this.phoneNo=phoneNo;
        this.passWord=password;
    }

}
